#!/usr/bin/env python
# coding: utf-8

# In[1]:



def chekprime(num):
     for i in range(2,num):
          if (num % i) == 0:
          
            return False
          else:
            return True
            
chekprime(6)


# In[2]:


lst = list(range(1,2500))

    


# In[3]:


lstprime = []


# In[4]:


for item in lst:
    if chekprime(item):
         lstprime.append(item)


# In[5]:


print(lstprime)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




