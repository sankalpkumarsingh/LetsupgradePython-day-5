#!/usr/bin/env python
# coding: utf-8

# In[6]:


uppercase = lambda str:str.upper()


# In[8]:


uppercase("hey")


# In[14]:


lst =["hey i am sankalp"]
uppercase = map(lambda lst:lst.upper(),lst)
list(uppercase)


# In[ ]:





# In[ ]:




